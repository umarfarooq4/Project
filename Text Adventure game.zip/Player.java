public abstract class Player{


//Class ATTRIBUTES
  
  public Room Position; // Position(x,y)
  public Thing Inventory; //Inventory
  
  
 // Player object
  public Player (Room Position) 
  {this.Position = Position;}
  
  
  // Method Despawn
  public void Despawn(Human man){
    Thing tem = this.Inventory;
    this.Inventory.Drop(this.Position);
    man.Pickup(tem);
    this.Position = null;
    
    // * * * * * Drop inventory (must do)* * * * *
  }
  
  
}//CLASS END 