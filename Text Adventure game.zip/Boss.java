public class Boss extends Enemy{

  
  public Boss(Room Position){
    
  //Initialization
    super(Position);
    this.HP = 10;
    this.DMG = 3;
    this.Worth = 100000000;
    this.Inventory = new Goal();
  
  
  }//Public Boss close

  public void Despawn(Human man){
    System.out.println("Biggest Douche cries, you slice his head off with a spoon and put it in your inventory. ");
    super.Despawn(man);
    
  }
  
  public void RoidUp(){
    
  if(this.HP <= 5){System.out.println("Boss takes out seringe with steroids and injects it into his bloodstream."+" his Damage dealt, doubles in strenght! ");
    this.DMG = 6;}
  
  
  }
  
}