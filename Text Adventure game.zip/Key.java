public class Key extends KeyItem{
  
  public Key(Room pos){super(pos);}
  public Key(){}

  public String ShowName(){
  
    return "mysterious key";
   
  }

}