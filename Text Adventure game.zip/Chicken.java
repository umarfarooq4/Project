public class Chicken extends Food{

  public int bonus = 10;

  
  public Chicken(Room pos){
  
  super(pos);
  
  }
  
    public String ShowName(){
  
    return "whole chicken";
  
  }
  
}