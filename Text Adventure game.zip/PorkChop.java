public class PorkChop extends Food{

  
  public PorkChop(Room pos){
      super(pos);
  this.bonus = 5;

  
  }
  public PorkChop(){super();this.bonus = 5;}
  
    public String ShowName(){
  
    return "pork chop";
  
  }
  
}