import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class World{
  
  public static void main(String[] args) {
    
      PrintWriter outputStream = null;
  try
  {
    outputStream = new PrintWriter(new FileOutputStream("worldintro.txt"));// if you want to make a new file then change worldintro.txt to for example demo.txt
  }
  catch (FileNotFoundException e)
  {
    System.out.println("Error opening the file worldintro.txt."); 
    System.exit(0);
  }
  System.out.println("Introduction to our game is provided in the worldintro.txt file.");
  outputStream.println("-----------------------------------------Welcome to Dream Team's Text Adventure Game----------------------------------------------------");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("The following grid is provided to show the overview of our Text Adventure game: ");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("           * = Wall's (no doors)");
  outputStream.println("           | = has door to adjacent room"); 
  outputStream.println("           L = locked doors"); 
  outputStream.println(" ");
  outputStream.println("            ____________________________________________________________________________________________________");
  outputStream.println("            *                               *                                 L                                *");
  outputStream.println("            *        Entrance               *          boss_room              L            key_room            *");
  outputStream.println("            *_______________________________*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL________________________________*");
  outputStream.println("            *                               *                                 |                                *");
  outputStream.println("            *         hall_1                *          gift_room              |            empty_2             *");
  outputStream.println("            *_______________________________*_________________________________|________________________________*");
  outputStream.println("            *                               |                                 |                                *");
  outputStream.println("            *         hall_2                |           empty_1               |            mean_room           *");
  outputStream.println("            *_______________________________|_________________________________|________________________________*");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("You are dropped in an entrance room which is the starting point of this game.");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("You notice that you are locked in and in order to escape this mysterious world you have to find the key which will unlock the door in the entranc room.");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("In this mysterious world you will encounter different players which you may have to fight or may not and many useful things.");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("Your starting health is 25 and can gain more health by picking food items.");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("You have to defeat the 'Boss' in order to get the key.");
  outputStream.println(" ");
  outputStream.println(" ");
  outputStream.println("Goodluck...");
  outputStream.close();
  
  
    
    boolean keyfound = false;
    boolean goalfound = false;
    boolean gameover = false;
    
    Room entrance = new Entrance();
    Room hall_1 = new Room();
    Room hall_2 = new Room();
    Room empty_1 = new Room();
    Room gift_room = new Room();
    Room mean_room = new Room();
    Room empty_2 = new Room();
    Room boos_room = new GoalRoom();
    Room key_room = new Room();
    
    
    Human human = new Human(entrance);
    DoucheBag1 douche1 = new DoucheBag1(hall_2);
    NPC1 goody = new NPC1(gift_room);
   //NPC1 goody = new NPC1(entrance);//TESTING
    DoucheBag2 douche2 = new DoucheBag2(mean_room);
    Riddler riddle  = new Riddler(key_room);
    //Riddler riddle  = new Riddler(entrance);//TESTING Riddler
    Boss boos = new Boss(boos_room);
    
    Room[] list = {null, null, hall_1, null};
    entrance.SetAdjacent(list);
    
    Room[] list1 = {entrance, null, hall_2, null};
    hall_1.SetAdjacent(list1);
    
    Room[] list2 = {hall_1, empty_1, null, null};
    hall_2.SetAdjacent(list2);
    
    Room[] list3 = {gift_room, mean_room, null, hall_2};
    empty_1.SetAdjacent(list3);
    
    Room[] list4 = {empty_2, null, null, empty_1};
    mean_room.SetAdjacent(list4);
    
    Room[] list8 = {boos_room, empty_2, empty_1, null};
    gift_room.SetAdjacent(list8);
    
    Room[] list5 = {key_room, null, mean_room, gift_room};
    empty_2.SetAdjacent(list5);
    
    Room[] list6 = {null, null, empty_2, boos_room};
    key_room.SetAdjacent(list6);
    
    Room[] list7 = {null, key_room, gift_room, null};
    boos_room.SetAdjacent(list7);
    
    
    System.out.println("You are dropped in a room. You notice that you are locked in.");                     
    System.out.println("But there seems to be a Key hole in the door behind you.");
    System.out.println("May aswell try the other door...");
    
    
    
    
    //ACTUAL GAME
    while( gameover == false){
      
      //unlock door
      if(riddle.Inventory.found == true){boos_room.roomtype = 0;}
      if(boos.Inventory.found == true){goalfound = true;}
      if(goalfound == true && human.Position == entrance){break;}
      System.out.print("What would you like to do? ('*' = commands) ");
      Scanner gamething = new Scanner(System.in);
      String inputFromPlayer = gamething.next();
      
      
      //Print the operations you need in game to do stuff
      if(inputFromPlayer.equals("*")){
        
        System.out.println("Quit the game: 'Q';");//Quit game
        System.out.println("To fight an ennemy in room: 'Fight'; ");//Fight
        System.out.println("To talk to an NPC: 'Talk' ");//Talk to NPC
        System.out.println("To pickup an item in the room: 'Pickup' ");//Pickup
        System.out.println("If you want to move: 'Move'; ");//Move
        System.out.println("     After you entered 'Move':  North = 'n', East = 'e', South = 's', West = 'w';");
        System.out.println(" ");
      }// "*" CLOSE
      
      //   QUIT
      else if(inputFromPlayer.equals("Q")){
        System.out.println("F@Cking quitter. ");
        gameover = true;
      }// QUIT CLOSE
      
      else if(inputFromPlayer.equals("Move")){
        //gamething.close();
        System.out.println("what direction? North:'n', East:'e', South:'s', West:'w'");
        Scanner direc_input = new Scanner(System.in);
        String SecondInput = direc_input.next();
        human.move(SecondInput);
        
        
        if(human.Position == entrance){System.out.println("You stand at the entrance, near a locked door");}
        if(human.Position == hall_2 && douche1.Position == hall_2){System.out.println("A douchebag stands before you, wearing a fearsom German helmet!!");}
        if(human.Position == gift_room && goody.Position == gift_room){System.out.println("A mysterious looking WIZARD with a crack pipe stands before you, eating pork.");}
        if(human.Position == mean_room && douche2.Position == mean_room){System.out.println("An EVEN SPOOKIER DOUCHEBAG stands before you, holding a sword.");}
        if(human.Position == key_room && riddle.Position == key_room){System.out.println("Jim Carrey from Batman Beyond stands before you, holding a crack pipe, his eyes as lifeless as his acting career.");}
        if(human.Position == boos_room && boos.Position == boos_room){System.out.println("A big veiny motherfucker stands before you. Syringes and a deadlife bar lie in the corner.");System.out.println(" ''You're a big guy'' you say to him.");System.out.println("''For you.'' He responds, chuckling.");}
        
        
      }
      
      //  TALK 
      else if(inputFromPlayer.equals("Talk")){
        
        // NPC1  TALK TOO
        if (goody.Position == human.Position){
          goody.dialogue(human);
        }
        
        //------------------------------------------//
        //NEED TO FIX RIDDLER TO DO THIS FOR RIDDLER//
        //------------------------------------------//
        
        else if(riddle.Position == human.Position){
          riddle.dialogue(human); 
        }
      }// TALK CLOSE
      
      
      
      //-----------------------------------------------//
      // the Following can be done better but whatever // 
      //-----------------------------------------------//
      
      else if(inputFromPlayer.equals("Fight")){
        
        //      DOUCHEBAG1 
        if(douche1.Position == human.Position){
          while ( human.HP > 0 && douche1.HP > 0 ){
            human.Fight(douche1, human);
            //System.out.println("human : "+ human.HP);//testing it
          }
        }//Douche1 CLOSE
        
        //DOUCHEBAG2
        if(douche2.Position == human.Position){
          while ( human.HP > 0 && douche2.HP > 0 ){
            human.Fight(douche2, human);
            //System.out.println("human : "+ human.HP);//testing it
          }
        }//Douche2 CLOSE
        
        // BOSS 
        if(boos.Position == human.Position){
          while ( human.HP > 0 && boos.HP > 0 ){
            boos.RoidUp();
            human.Fight(boos, human);
            //System.out.println("human : "+ human.HP);//testing it
          }
        }//boos (BOSS) CLOSE
        
        
        //  Print Statement if nothing to fight in the room:
        else if(boos.Position != human.Position || douche2.Position != human.Position || douche2.Position != human.Position){
          System.out.println(" There is nothing to fight in the room ");}
      }// FIGHT CLOSE
      
      
      
    }// While loop for game close
    
    System.out.println(" ");
    System.out.println("End of Game");
    
    if(goalfound == true && human.Position == entrance){System.out.println("You win!!!");}
    
  }
}
