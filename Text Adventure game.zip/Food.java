public abstract class Food extends Bonus{

  

  public Food(Room pos){
  super(pos);
  this.isfood = true;
  }
  public Food(){super(); this.isfood = true;}
}