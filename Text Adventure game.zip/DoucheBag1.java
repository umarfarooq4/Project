public class DoucheBag1 extends Enemy{

  
  public DoucheBag1(Room Position){
    
  //Initialization
    super(Position);
    this.HP = 20;
    this.DMG = 1;
    this.Worth = 2;
    this.Inventory = new Pickelhelm();
  
  
  }//Public Douchebag1 close

  public void Despawn(Human man){
    System.out.println("Douchebag1 passes out from drinking too much. ");
    super.Despawn(man);
    
  }
}