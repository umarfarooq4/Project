public abstract class Bonus extends Thing{

  public int bonus;
  
  public Bonus(){}
  public Bonus(Room pos){
  
  super(pos);
  
  }

  public int Despawn(){
  
  this.position = null;
  return this.bonus;
  
  }

}