public abstract class KeyItem extends Thing{

  
  
  public KeyItem(Room pos){super(pos);}
  public KeyItem(){}
  
  public int Despawn(){
  
  this.found = true;
  super.Despawn();
  return 0;
  
  }
  
}