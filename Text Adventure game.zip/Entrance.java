public class Entrance extends Room{
  
  public int roomtype = 1;

  public Entrance(){}
  
}