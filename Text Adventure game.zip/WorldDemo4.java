import java.util.Scanner;
public class WorldDemo4{
  
  public static void main(String[] args) {
    
    boolean gameover = false;
    
    Room entrance = new Entrance();
    Room hall_2 = new Room();
    
    Human human = new Human(entrance);
    Boss boos = new Boss(hall_2);
    
    Room[] list = {null, null, hall_2, null};
    entrance.SetAdjacent(list);
    
    Room[] list1 = {entrance, null, null, null};
    hall_2.SetAdjacent(list1);

      //ACTUAL GAME
    while( gameover == false){
      
      //unlock door
      
      System.out.print("What would you like to do? ('*' = commands) ");
      Scanner gamething = new Scanner(System.in);
      String inputFromPlayer = gamething.next();
      
      
      //Print the operations you need in game to do stuff
      if(inputFromPlayer.equals("*")){
        
        System.out.println("Quit the game: 'Q';");//Quit game
        System.out.println("To fight an ennemy in room: 'Fight'; ");//Fight
        System.out.println("To talk to an NPC: 'Talk' ");//Talk to NPC
        System.out.println("To pickup an item in the room: 'Pickup' ");//Pickup
        System.out.println("If you want to move: 'Move'; ");//Move
        System.out.println("     After you entered 'Move':  North = 'n', East = 'e', South = 's', West = 'w';");
        System.out.println(" ");
      }// "*" CLOSE
      
      //   QUIT
      else if(inputFromPlayer.equals("Q")){
        System.out.println("F@Cking quitter. ");
        gameover = true;
      }// QUIT CLOSE
      
      else if(inputFromPlayer.equals("Move")){
        //gamething.close();
        System.out.println("what direction? North:'n', East:'e', South:'s', West:'w'");
        Scanner direc_input = new Scanner(System.in);
        String SecondInput = direc_input.next();
        human.move(SecondInput);
        
        
        if(human.Position == entrance){System.out.println("You stand at the entrance, near a locked door");}
        if(human.Position == hall_2 && boos.Position == hall_2){System.out.println("A big veiny motherfucker stands before you. Syringes and a deadlife bar lie in the corner.");System.out.println(" ''You're a big guy'' you say to him.");System.out.println("''For you.'' He responds, chuckling.");}
        
      }
      
      //  TALK 
      else if(inputFromPlayer.equals("Talk")){
        
        System.out.println("This be a fighting demo");
      }// TALK CLOSE
      
      
      
      //-----------------------------------------------//
      // the Following can be done better but whatever // 
      //-----------------------------------------------//
      
      else if(inputFromPlayer.equals("Fight")){
        
       if(boos.Position == human.Position){
          while ( human.HP > 0 && boos.HP > 0 ){
            boos.RoidUp();
            human.Fight(boos, human);
            //System.out.println("human : "+ human.HP);//testing it
          }
        
       }
      }// FIGHT CLOSE
      
      
      //PICKUP IF IN ROOM COMMAND
      else if(inputFromPlayer.equals("Pickup")){
        
        // * * * FIX THIS SHIT * * * //
        //if (Thing.Position == human.Position){
        // human.Pickup(Thing);}
        
      }
      
      
      
    }// While loop for game close
    
    System.out.println(" ");
    System.out.println("End of Game");

  }
  
  
  
}