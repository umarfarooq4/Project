public class Human extends Fighting implements Movement{

//  CLASS ATTRIBUTES
  public int LVL = 1;
  public int XP = 0;
  
//   * * * SUPERS * * *
  public Human(Room Position){
    
    super(Position);
    this.HP = 25;
    this.DMG = 5;
  }
    
  public void Pickup(Thing item){
    
  // THIS CONVERTS BONUS TO THINGS IN PLAYER CLASS
    
    System.out.println("You picked up a " + item.ShowName() + ".");
    if(item.isfood){this.HP += item.Despawn(); System.out.println("Your HP is now " + this.HP);}
    else{this.DMG += item.Despawn(); System.out.println("Your Damage is now " + this.DMG);}

  }//Closes Human Object

  //Game over If player dies
  public void Despawn(){
  System.out.println(" Fuckin noob. You suck. GG ");
  System.exit(0);// ENDs Game
  }
  
  public void Fight(Fighting f1, Human man){
    System.out.println("You dealt " + this.DMG + " damage, and your current HP is " + this.HP + ".");
    super.Fight(f1, man);
  
  }
 
  
    public void move(String dir){
      //*****FIX DIS SHIT*****
   
      Room temp = this.Position;
      
      if(dir.equals("n")){
        if(temp.AdjacentRooms[0] == null){System.out.println("You walk into a wall, dumbass.");}
        else{
         this.Position = temp.AdjacentRooms[0];
        }
      }
      else if(dir.equals("e")){
        if(temp.AdjacentRooms[1] == null){System.out.println("You walk into a wall, dumbass.");}
        else{
        this.Position = temp.AdjacentRooms[1];
        }
      }
      else if(dir.equals("s")){
        if(temp.AdjacentRooms[2] == null){System.out.println("You walk into a wall, dumbass.");}
        else{
        this.Position = temp.AdjacentRooms[2];
        }
      }
      else if(dir.equals("w")){
        if(temp.AdjacentRooms[3] == null){System.out.println("You walk into a wall, dumbass.");}
        else{
        this.Position = temp.AdjacentRooms[3];
        }
      }
      else{System.out.println("thats not a valid entry for a direction. (n / e / s / w) are your options.");}
      
      //Check if the door is locked
      if(this.Position.roomtype == 2){this.Position = temp; System.out.println("This door is locked! You need a key.");}
      
  }


}// Class close Squiggly

    /*if(dir is n){
     * Room temp = this.Position;
     this.Position = temp.AdjacentRooms[0];
    
    */
    
    
    
    
    
    
    