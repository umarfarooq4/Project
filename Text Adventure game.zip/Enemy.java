public abstract class Enemy extends Fighting{

  //CLASS ATTRIBUTES
  public int Worth;
  
  
//  * * * SUPERS * * *
  public Enemy(Room Position){super(Position);}

}