public abstract class NPC extends Player{
 
 
  
  // Initializeeee 
  public NPC(Room Position){
    super(Position);}
  
  public void dialogue(Human man){
    
    // Once player is Dead
    Despawn(man);
    
    }
  
  
}//END CLASS