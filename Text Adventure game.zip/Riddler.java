import java.util.Scanner;

public class Riddler extends NPC{
  
  public Riddler(Room Position){
    super(Position);
    this.Inventory = new Key();
    //Inventory = new Key();
 //---------------------------//
 //    NEED TO FIX THIS:      //
 //   Inventory = new Key();  //
 //---------------------------//
  }
  
  
  
  // RIDDLE 
  @Override
  public void dialogue(Human man){

    //Shit he needs to say
    Scanner key = new Scanner(System.in);
    System.out.println("The 8 of us go forth, not back, to protect our king from a foe's attack. What are we?");
    
    while(true){
      System.out.println( "dumbass, try again");
      if("pawns".equals(key.next())){break;}
    }
    this.Despawn(man);// Despawn if they get riddle
    //while wrong
    
    
    System.out.println("Yea im gonna disapear now, later Noob");

  }
  
}// end of clas