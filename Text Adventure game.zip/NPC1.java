public class NPC1 extends NPC{
  
  //NPC1 Object
  public NPC1(Room Position){
    super(Position);
    this.Inventory = new PorkChop();
    }
  
  // Must change what is bellow for dialogue
  
  @Override
  public void dialogue(Human man){
    System.out.println("Shit's afoot here's a Pork chop.");
    super.dialogue(man);
    //Inventory.Drop(this.Position);//Drops the porkchop
   
    
// * * * GIVE THIS GUY A PORKCHOP, Must Do * * * 
    
  }//Despawn close
  
}// CLASS END
