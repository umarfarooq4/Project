public class Longsword extends Bonus{

  
  public Longsword(Room pos){
  
  super(pos);
  this.bonus = 3;
  }
  public Longsword(){super();this.bonus = 3;}
  
    public String ShowName(){
  
    return "Longsword";
  
  }
  
}