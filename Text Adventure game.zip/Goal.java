public class Goal extends KeyItem{public Goal(Room pos){super(pos);}
  public Goal(){}

  public String ShowName(){
  
    return "magical orb";
  
  }

  public String PathFind(Room pos, Room exit){
  
  //***Insert Pathfinding here***
  //Returns next step toward the exit (N,E,S,W)
  
  return "Nothing here yet";
    
  }
  
  public int Despawn(){
    System.out.println("The orb imparts its wisdom onto you. You know that the way home is South, South, West, North, North");
    super.Despawn();
    return 0;
    }
    
}