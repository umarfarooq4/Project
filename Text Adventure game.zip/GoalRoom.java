public class GoalRoom extends Room{
  
  public GoalRoom(){this.roomtype = 2;}
  
}