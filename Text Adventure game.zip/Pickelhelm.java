public class Pickelhelm extends Bonus{

  
  public Pickelhelm(Room pos){
  
  super(pos);
  this.bonus = 2;
  }
  public Pickelhelm(){super();this.bonus = 2;}
    public String ShowName(){
  
    return "GLORIOUS GERMAN HELMET";
  
  }
  
}